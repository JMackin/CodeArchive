/*
 *CS 235 Fall 2019 Assignment 1
 * John Mackin
 * 10/03/10
 **/

class cookeryStudent
{
  
}
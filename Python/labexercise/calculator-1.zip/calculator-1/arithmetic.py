def add(num1, num2):
    return 10

def subtract(num1, num2):
    pass

def multiply(num1, num2):
    pass

def divide(num1, num2):
    pass

def square(num1):
    pass

def cube(num1):
    pass

def power(num1, num2):
    pass

def mod(num1, num2):
    pass
